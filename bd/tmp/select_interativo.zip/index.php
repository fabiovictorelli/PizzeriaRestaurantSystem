<html>

<head>
  <title></title>
</head>

<body><center><font face="verdana">
<table width="100%" border="0" bordercolor="#000000" bgcolor="#FFE1D2">
  <td bgcolor="#FFC2A6" align="left" colspan="4">Select Interativo v1.0
  <tr>
    <td height="22">&nbsp;</td>
  </tr>
  <tr>
    <td align="left">1- <a href="mostratab.php" target="destino">Listar Todas as Tabelas de Uma Base de Dados</a><br>2- <a href="mostradadostab.php" target="destino">Obter Informa&ccedil;&otilde;es Sobre Uma Tabela</a><br>
      3- <a href="select.php" target="destino">Executar Um Select</a></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
    <iframe name=destino frameBorder=0 marginHeight=0 marginWidth=0 scrolling=aways src="inicio.php" width=100% height=400 bordercolor="#000000">
<ilayer id=full visibility=hide width=100% height=400></ilayer></IFRAME>
    Email:<a href="mailto:neander@eumesmo.com.br">Neander Ara�jo</td>
  </tr>
</table>
</body>

</html>