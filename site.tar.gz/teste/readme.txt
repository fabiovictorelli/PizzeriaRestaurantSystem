PHP Flash SlideShow 0.2

DESCRIPTION:
PHP Flash SlideShow is PHP class to create simple flash slideshow from sequences of JPEG images. It require Ming PHP Extension, otherwise this class WILL NOT WORK.
see example files how to use this class.

REQUIREMENT:
You MUST HAVE PHP with Ming installed as PHP Extension.
You can see if Ming Installed by see phpinfo();
see http://ming.sourceforge.net and http://php.net/manual/en/ref.ming.php for more info
Ask your web server administrator if you don't know how to install it

TODO IN NEXT RELEASE 0.4:
- transition effect between each image
- align images in center of the movie
- automatic scaling of images to fit movie size
- some input validation

SUPPORT:
I'm not provide any technical support. To contact me, view my email in class.flashslideshow.php