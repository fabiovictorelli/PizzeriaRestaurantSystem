<?PHP
   require ( "lib/victorelli.lib.php");
   MostraCabec("Alteracao de Clientes ");

	$conn = pg_Connect("localhost", "5432", "", "", "victorelli");
	     
	if (!$conn) {
		echo "N�o foi possivel abrir banco de dados.\n";
	exit;
	}
        if (empty($nome)) {
		MostraErro("O campo nome � obrigatorio !\n");
	}
        if (empty($endereco)) {
		MostraErro("O campo endereco deve ser preenchido!\n");
	}
        if (empty($telefone)) {
		MostraErro("O campo telefone deve ser preenchido!\n");
	}

/*** Gravando na base   ***/
	echo "Alterando projeto numero=$numero<BR>";

//		datainicioproj = '$datainicioproj', 

	$result = pg_Exec($conn, "update clientes set nome = '$cliente', 
		endereco = '$endereco' where telefone = '$telefone';");

	if (!$result) {
		echo "Ocorreu um erro durante a altera�ao da base de dados.\n";
		exit;
	}
	echo "<CENTER><BR>Cliente alterado. </CENTER>";
	pg_FreeResult($result);
	pg_Close($conn);
	MostraRodape();
?>
