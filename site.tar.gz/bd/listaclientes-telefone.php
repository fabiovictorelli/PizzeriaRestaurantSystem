<?PHP 
   require ( "./lib/victorelli.lib.php");
   MostraCabec("Lista clientes por telefone ");

   $conn = pg_Connect("localhost", "5432", "", "", "victorelli");
	     
   if (!$conn) {
      SaiErro ("Nao foi possivel abrir banco de dados.\n");
   }
   $result = pg_Exec($conn, "Select * from clientes ORDER BY telefone;");
   $num = pg_NumRows($result);

   if($num == 0) {
      MostraErro("N�o existem clientes cadastradas!\n<BR>Voc� deve cadastrar um cliente primeiro !\n");
   }

   echo "<table  border=\"1\"  cellpadding=\"1\" cellspacing=\"1\">";
   for($i = 0; $i < $num; $i++) {
      echo "<tr align=\"left\"> <td>";
      echo pg_Result($result, $i, "telefone");
      echo "</td><td>";
      echo pg_Result($result, $i, "nome");
      echo "</td><td>";
      echo pg_Result($result, $i, "endereco");
      echo "</td><td>";
      $dataformatolong = pg_Result($result, $i, "data_cadastro");
      $aux = strftime("%d/%m/%Y - %H:%M:%S",$dataformatolong);
      echo "$aux";
      echo "</td></tr>";
   }
   echo "</table>";
   
   pg_FreeResult($result);
   pg_Close($conn);
?>                              
<BR>
</CENTER>
</FORM>
<?PHP MostraRodape(); ?>
