
<?
/*
Le o arquivo indicado por $arquivo  linha por linha, separando os campos
pelo delimitador $delim
e armazena o resultado de cada campo em uma celula da tabela HTML
Funciona para qqer arquivo. Basta informar o delimitador
*/
?>
<?

$SITE_LOCAL="localhost";
$DIR_HOME="/home/httpd/html/ed";
$ERRO=-1;   // Ver em ValidaData()

   function Configuracao($var) {
      $DIR_HOME="/home/httpd/html/ed";
      $arquivo = "$DIR_HOME/conf/ed.cfg";   /* Indique aqui o nome do arquivo */
      $delim = "=";           /*Indique aqui o delimitador */

      $arq_array = file("$arquivo");/*cada linha do arq vai para uma posic. do array*/
      for($i = 0; $i < sizeof($arq_array); $i++) {
         if ( ! ereg( "#" , $arq_array[$i]) ) {         // se n�o achei o "#" na linha
               /* a fun��o split abaixo separa a linha pelo delimitador (#) e
                joga os campos num array (semelhante ao cut do shell) */
            $lin_array = split( $delim , $arq_array[$i]);
            for($j = 0; $j < sizeof($lin_array); $j++) {
               if ( strlen( $lin_array[$j]) > 1 ) 
                  if ( $j == 0 ) {
                     if ( $lin_array[$j] == $var ) {
                        //echo  $lin_array[$j + 1];
                        $aux=trim($lin_array[$j + 1]);
                        return ($aux);
                     }
                  }
            }
         }
      }
      $ERRO="ERRO - Nao existe a variavel $var no arquivo $arquivo<BR>";
      return ( $ERRO );
   } // Fim de Funcao Configuracao

// a funcao _( foi implementada no PHP4, � um alias para a fun��o gettext, entao:
$language = "pt_BR";
$locale = setlocale(LC_ALL, $language );
$gettext_domain = 'victorelli';
// Specify location of translation tables
bindtextdomain($gettext_domain, "/home/fabio/site/bd/locale");
// Choose domain
textdomain($gettext_domain);

//   function _($texto) {
//   $fp = popen( "gettext ed \"$texto\"", "r" );
//      $var = fgets($fp,4096);
//      pclose ($fp);
//      return ($var);
//   }

   function MostraHora() {
           //$data_atual = date("d/m/Y"); 
      print strftime("%d/%m/%Y - %H:%M:%S"); 
   } // Fim de Funcao MostraHora

   function MostraCabec($cabecalho) {
      echo "<HTML>";
      echo "<HEAD>";
      echo "<TITLE> Victorelli - Sistema de Clientes </TITLE>";
      echo "</HEAD>";
      echo "<BODY BGCOLOR=\"#FFFFFF\" TEXT=\"#000000\" LINK=\"#0000FF\" VLINK=\"#000080\" ALINK=\"#FF0000\">";
      echo "<TABLE WIDTH=100% BORDER=0>";
      echo "<TR><TD>";
      echo "<H4>$cabecalho</H4>";
      echo "</TD><TD>";
      echo "<CENTER><P><IMG SRC=\"../images/logo-mini.jpg\" ALT=\"";
      echo _("Victorelli Sistema");
      echo "\"";
      echo "HEIGHT=50 WIDTH=252></P></CENTER> ";
      echo "</TD><TD>";
                MostraHora();
      echo "<TD></TR>";
      echo "</TABLE>";
   } // Fim de Funcao MostraCabec

   function MostraRodape() {
      echo "<hr size=1 align=center>";
      echo "<BR><form><input type=\"button\" value=\"";
      echo _("Back");
      echo "\" onClick=\"history.back()\"></form>";
      echo "</BODY>";
      echo "</HTML>";
   } // Fim de Funcao MostraRodape

   function ValidaData($data) {
      echo "<BR>data=[$data]";
      if (empty($data)) {
        echo "<BR>Erro";
	return $ERRO;
      }
   }


function send_mail($to_address, $from_address, $subject, $message) {

      $path_to_sendmail = "/usr/lib/sendmail";

      $fp = popen("$path_to_sendmail -t", "w");
      $num = fputs($fp, "To: $to_address\n");
      $num += fputs($fp, "From: $from_address\n");
      $num += fputs($fp, "Subject: $subject\n\n");
      $num += fputs($fp, "$message");
      pclose($fp);

      if ($num > 0) {
        return 1;
      } else {
        return 0;
      }

}

// SaiErro ()
// fabio@conectiva.com.br
// somente avisa o erro GRAVE
// pede para usu�rio avisar o webmaster
// coloca bot�o retornar
// e sai
function SaiErro($msg)
{
        echo "<BR><H4>Erro!!</H4>";
        echo "<BR>$msg";
        echo "<BR>Envie email para o webmaster!<BR>";
        echo "<form>";
            echo "<input type=\"button\" value=\"Retornar\" onClick=\"history.back()\">";
        echo "</form>";
        exit;
}    
// MostraErro ()
// fabio@conectiva.com.br
// somente avisa o erro,
// coloca bot�o retornar
// e sai
function MostraErro($msg)
{
        echo "Erro!!";
        echo "$msg";
        echo "<form>";
        echo "<input type=\"button\" value=\"Retornar\" onClick=\"history.back()\">";
        echo "</form>";
        exit;
}     

function MostraeSai($msg)
{
        echo "<BR>$msg";
        echo "<form>";
        echo "<input type=\"button\" value=\"Retornar\" onClick=\"history.back()\">";
        echo "</form>";
        exit;
}     




function TabelaOK($conn,$tabela)
{
    $result__local = pg_Exec($conn, "Select * from $tabela ;");
    $num__local = pg_NumRows($result__local);
    if ( $num__local == 0 ) {
          MostraErro ("N�o existem dados na tabela $tabela cadastradas!.");
    }    
    pg_freeresult($result__local);
    return ;
}

function GravaLog ( $arquivo, $texto )
{
    $DIR_HOME="/home/httpd/html/ed";
   if ( $arquivo == webmaster ) {
      $ARQ_LOG = "$DIR_HOME/logs/webmaster.log";
   }
   if ( $arquivo == professor ) {
      $ARQ_LOG = "$DIR_HOME/logs/professor.log";
   }
   if ( $arquivo == aluno ) {
      $ARQ_LOG = "$DIR_HOME/logs/aluno.log";
   }

//   echo "arquivo=$arquivo , texto=$texto, ARQ_LOG=$ARQ_LOG\\n";
   $fp = fopen("$ARQ_LOG", "a+");
   $data_atual = date("d/m/Y"); 
   $Texto_log="$data_atual - $texto\n";
   fwrite($fp,$Texto_log);
   fclose($fp);
}

function CriaDir ($dir) {
    $ret = mkdir ("$dir" , 0777 );
    if (!$ret) {
        SaiErro ("<BR>\nOcorreu um erro durante a cria��o do diret�rio $dir .\n");
    }    
    $DIR_HOME="/home/httpd/html/ed";
   $origem= sprintf( "%s/%s",$DIR_HOME ,"/lib/listadir.php");
   $destino = sprintf( "%s/%s", $dir,"index.php");
   if (!copy($origem, $destino)) {
       SaiErro("Erro durante a cria��o do arquivo $dir/index.php..\n");
   }

    return ( 0 );
}

function RemoveDir ($dir) {
    $ret = rmdir ("$dir");
    if (!$ret) {
      SaiErro ("<BR>Ocorreu um erro durante a remo��o do diretorio $dir \n");
    }    
    return ( 0 );
}


/*********************************************************
*  Fabio D Victorelli
*  dom jul  4 15:29:56 EST 1999
*  img_upload = envia arquivo para um curso
*********************************************************/

function img_upload($arquivotmp,$arquivo_real_name,$rota_destino) 
{ 
$arquivotmp = stripslashes($arquivotmp);

   $i = "0"; 
   $d = dir($rota_destino); 
   while($entry=$d->read())  
   { 
      if($entry == $arquivo_real_name) 
      { 
         $arquivo_real_name_in_use = "TRUE";
      } 
      ++$i; 
   } 
                    
$d->close(); 
   if($arquivo_real_name_in_use == "TRUE") {  
      $new_arquivo_real_name = $arquivo_real_name.date('hms');
      echo "<BR>Aten��o j� existia arquivo com o nome: $arquivo_real_name!";
      echo "<BR>Gravei arquivo com novo nome:$new_arquivo_real_name";
   } 
   else {  
      $new_arquivo_real_name = $arquivo_real_name;
   } 
   $new_img_location = $rota_destino. '/'.$new_arquivo_real_name;

   if ( ! copy($arquivotmp,$new_img_location) ) {
      SaiErro("Erro copiando arquivo $arquivotmp para $new_img_location ");
   }

   if ( ! chmod($new_img_location, 0666) ) {
      SaiErro("Erro mudando a permiss�o do arquivo $new_img_location ");
   }

   $img_upload_array = array("$new_arquivo_real_name","$new_img_location");
                                     
return($img_upload_array);      
} 
/*-----------------------------///  img_upload()  ///-------------------------*/


/*
class foo {
    function do_foo () {
        echo "Doing foo.";
    }
}

$bar = new foo;
$bar -> do_foo ();    
*/

?>       
