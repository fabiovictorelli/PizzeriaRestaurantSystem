<?PHP 
   require ( "lib/victorelli.lib.php");
   MostraCabec("Inclus�o de Clientes ");
?>

<?PHP
        $telefone=$_POST['telefone'];
        $nome=$_POST['nome'];
        $endereco=$_POST['endereco'];

//        echo "variaveis= [$telefone] [$nome] [$endereco]";
//        echo "<BR>";

// Verificando se o usuario preencheu os campos obrigatorio
   if (empty($telefone)) {
      MostraErro( "<BR><BR> O campo Telefone deve ser preenchido!<BR>");
   }
   if (empty($nome)) {
      MostraErro( "<BR><BR> Voc� deve preencher o NOME!  <BR><BR> <BR><BR>");
   }
   if (empty($endereco)) {
      MostraErro( "<BR><BR> Voc� deve preencher um ENDERECO !  <BR><BR> <BR><BR>");
   }

   $conn = pg_Connect("localhost", "5432", "", "", "victorelli");

   if (!$conn) {
      echo "N�o foi possivel abrir banco de dados.\n";
      exit;
   }

// Verificando se o telefone ja esta gravado
   $testafone = pg_Exec($conn, "select * from clientes WHERE telefone = $telefone;");
   $num = pg_NumRows($testafone);
   $i=0;
   for($i = 0; $i < $num; $i++) {
      // trim() tira os espacos em brancos  do comeco ate o fim da base de dados 
      $auxfone= trim(pg_Result( $testafone, $i, "telefone" ));
      $auxnome= trim(pg_Result( $testafone, $i, "nome" ));
      $auxendereco= trim(pg_Result( $testafone, $i, "endereco" ));
      $ret=strcmp ( $auxfone, $telefone );
      if ( $ret == 0 ) {
         //echo "<BR>auxfone=$auxfone telefone=$telefone i=$i num=$num"; 
         pg_Close($conn);
         MostraeSai("<BR>telefone <b>$telefone</b> cadastrado para:
                      <b><BR>$auxnome <BR>Endereco:$auxendereco</b>");
      }
      else {
         echo "<BR>auxfone=$auxfone telefone=$telefone"; 
      }
   }

// Gravando os dados na base de dados
   $cep = 1111;
   //$data_hoje = getdate();    
   //$data_hoje = "2004-01-25";

   $data_hoje = mktime(date('G,i,s,m,d,Y')); //guarda o valor em segundos decorridos desde 01/01/1970 - 0h0min0s at� o segundo atual 
   echo "data_hoje = $data_hoje";
   $result = pg_Exec($conn,
                        "INSERT INTO clientes VALUES ('$telefone','$nome','$endereco','$cep','$data_hoje');");
   if (!$result) {
      echo "Ocorreu um erro durante a inclusao na base de dados.\n";
      exit;
   }

   echo "<CENTER>";
   echo "<BR><BR>Cliente inclu�do";
   echo "</CENTER>";
   pg_FreeResult($result);
   pg_Close($conn);
?>
<?PHP MostraRodape(); ?>
