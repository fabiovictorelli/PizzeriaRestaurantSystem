<?PHP 
   require ( "lib/victorelli.lib.php");
   MostraCabec("Alteracao de Clientes ");
?>

<?PHP
   $conn = pg_Connect("localhost", "5432", "", "", "victorelli");

   if (!$conn) {
      echo "N�o foi possivel abrir banco de dados.\n";
      MostraRodape();
      exit;
   }

   $telefone=$_POST['telefone'];
   $nome=$_POST['nome'];
   $endereco=$_POST['endereco'];

   echo "variaveis= [$telefone] [$nome] [$endereco]";
   echo "<BR>";

   echo "<FORM ACTION=\"dbaltera2.php\" METHOD=\"POST\">";
   echo "<P>Telefone: $telefone <BR>";
   echo "<INPUT TYPE=\"hidden\" NAME=\"telefone\" VALUE=\"$telefone\" SIZE=\"10\"></INPUT>";
   echo "Nome:";
   echo "<INPUT TYPE=\"text\" NAME=\"nome\" VALUE=\"$nome\" SIZE=\"70\"></INPUT> <BR>";
   echo "<P>Endere�o:";
   echo "<INPUT TYPE=\"text\" NAME=\"endereco\" VALUE=\"$endereco\" SIZE=\"87\"></INPUT> <BR><BR>";

   pg_Close($conn);
?>

<INPUT TYPE="submit" VALUE="Alterar"></INPUT>
<INPUT TYPE="reset" VALUE="Limpar"></INPUT>
</CENTER>
</FORM>
<?PHP MostraRodape(); ?>
