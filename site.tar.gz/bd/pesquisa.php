<?PHP 
   require ( "./lib/victorelli.lib.php");
   MostraCabec("Pesquisa de Clientes:");
?>

<FORM ACTION="dbpesquisa.php" METHOD="POST">
<?PHP
     echo "<P>Telefone:";
     echo "<INPUT TYPE=\"text\" NAME=\"telefone\" SIZE=\"10\"></INPUT>";
?>                              

<INPUT TYPE="submit" VALUE="Pesquisar"></INPUT>
<INPUT TYPE="reset" VALUE="Limpar"></INPUT>
</CENTER>
</FORM>
<?PHP MostraRodape(); ?>
