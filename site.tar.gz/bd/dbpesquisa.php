<?PHP 
   require ( "lib/victorelli.lib.php");
   MostraCabec("Pesquisa de Clientes ");
?>

<?PHP
        $telefone=$_POST['telefone'];
        $nome=$_POST['nome'];
        $endereco=$_POST['endereco'];

//        echo "variaveis= [$telefone] [$nome] [$endereco]";
//        echo "<BR>";

// Verificando se o usuario preencheu os campos obrigatorio
   if (empty($telefone)) {
      MostraErro( "<BR><BR> O campo Telefone deve ser preenchido!<BR>");
   }

   $conn = pg_Connect("localhost", "5432", "", "", "victorelli");

   if (!$conn) {
      echo "N�o foi possivel abrir banco de dados.\n";
      exit;
   }

// Verificando se o telefone ja esta gravado
   $testafone = pg_Exec($conn, "select * from clientes WHERE telefone = $telefone;");
   $num = pg_NumRows($testafone);
   $i=0;
   for($i = 0; $i < $num; $i++) {
      // trim() tira os espacos em brancos  do comeco ate o fim da base de dados 
      $auxfone= trim(pg_Result( $testafone, $i, "telefone" ));
      $auxnome= trim(pg_Result( $testafone, $i, "nome" ));
      $auxendereco= trim(pg_Result( $testafone, $i, "endereco" ));
      $ret=strcmp ( $auxfone, $telefone );
      if ( $ret == 0 ) {
         //echo "<BR>auxfone=$auxfone telefone=$telefone i=$i num=$num"; 
         pg_Close($conn);
         echo "<table>";
         echo "<TR><TD>";
         echo"<BR>telefone <b>$telefone</b> j� est� cadastrado para: <b><BR>$auxnome <BR>Endereco:$auxendereco</b>";
         echo "</TD><TD>";
         echo "<FORM ACTION=\"dbaltera.php\" METHOD=\"POST\">";
         echo "<INPUT TYPE=\"hidden\" NAME=\"telefone\" VALUE=\"$auxfone\" SIZE=\"10\"></INPUT>";
         echo "<INPUT TYPE=\"hidden\" NAME=\"nome\" VALUE=\"$auxnome\" SIZE=\"70\"></INPUT> <BR>";
         echo "<INPUT TYPE=\"hidden\" NAME=\"endereco\"  VALUE=\"$auxendereco\" SIZE=\"87\"></INPUT><BR><BR>";
         echo "<INPUT TYPE=\"submit\" VALUE=\"Alterar\"></INPUT>";
         echo "</FORM>";
         echo "</TD></TR>";
         echo "<table>";
         MostraRodape();
         exit;
      }
      //echo "<BR>auxfone=$auxfone telefone=$telefone"; 
   }

   echo "Telefone ainda nao cadastrado, vamos cadastrar:";
   echo "<FORM ACTION=\"dbinclusao.php\" METHOD=\"POST\">";
   echo "<P>Telefone:";
   echo "<INPUT TYPE=\"text\" NAME=\"telefone\" VALUE=\"$telefone\" SIZE=\"10\"></INPUT>";
   echo "Nome:";
   echo "<INPUT TYPE=\"text\" NAME=\"nome\" SIZE=\"50\"></INPUT> <BR>";
   echo "<P>Endere�o:";
   echo "<INPUT TYPE=\"text\" NAME=\"endereco\" SIZE=\"67\"></INPUT> <BR><BR>";

   pg_Close($conn);
?>

<INPUT TYPE="submit" VALUE="Cadastrar"></INPUT>
<INPUT TYPE="reset" VALUE="Limpar"></INPUT>
</CENTER>
</FORM>
<?PHP MostraRodape(); ?>
